--A. Belirli Kolonları Seçme
SELECT FirstName, LastName, Salary
FROM employees;
--B. DISTINCT Komutu ile Tekrarları Önleme
SELECT DISTINCT FirstName, LastName, Salary
FROM employees;
--C. Belirli Bir Departmana Ait Çalışanları Listeleme
SELECT*FROM employees, departments WHERE departmentname = 'IT'
--D. Maaşa Göre Sıralama
SELECT*FROM employees
ORDER BY salary DESC
--E. Kolonları Birleştirme
SELECT FirstName || ' ' || LastName as Full_Name
FROM employees;