--1. SORU
SELECT SUM(total) AS total_amount
FROM invoice
WHERE TO_CHAR(invoice_date, 'YYYY') = '2009' AND billing_country = 'USA';

--2. SORU

SELECT	p.playlist_id, p.name,
		t.track_id, t.name, t.album_id,
    t.mediatype_id,
    t.genre_id,
    t.composer,
    t.milliseconds,
    t.bytes,
    t.unitprice
FROM playlist p
INNER JOIN playlisttrack pt ON p.playlist_id = pt.playlist_id

INNER JOIN track t ON pt.track_id = t.track_id

--3.SORU
SELECT	a.artist_id, a.name,
		al.title, al.album_id,
		t.track_id, t.name,
    	t.mediatype_id, t.genre_id,
    	t.composer, t.milliseconds,
    	t.bytes, t.unitprice
FROM artist a
INNER JOIN album al ON a.artist_id = al.artist_id
INNER JOIN track t ON t.album_id = al.album_id
WHERE al.title = 'Let There Be Rock'
ORDER BY milliseconds DESC;