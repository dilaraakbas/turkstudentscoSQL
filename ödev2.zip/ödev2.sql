--1. Soru
SELECT COUNT(*)
FROM invoice
WHERE invoice_id IS NULL 
  AND customer_id IS NULL 
  AND invoice_date IS NULL 
  AND billing_address IS NULL 
  AND billing_city IS NULL 
  AND billing_state IS NULL 
  AND billing_country IS NULL 
  AND billingpostal_code IS NULL 
  AND total IS NULL;




--2. Soru
SELECT 
       total AS _total, 
       CASE 
           WHEN total IS NOT NULL THEN total * 2  
       END new_total
FROM invoice
ORDER BY new_total DESC;

--3. Soru
SELECT
	billing_address,
	CONCAT(SUBSTRING(billing_address, 1, 3), ' ', SUBSTRING(billing_address, length(billing_address)-3, 4)) AS "AÇIK ADRES"
FROM invoice
WHERE TO_CHAR(invoice_date, 'YYYY-MM') = '2013-08';